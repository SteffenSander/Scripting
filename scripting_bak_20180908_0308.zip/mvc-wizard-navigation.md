

[Anpassungen in]
fnc: bindClickHandler process argument (default als string)
    omit callback function callLoadOptionsView wenn dialog settings falsy


[Dokumentation]
fnc: 