

[Anpassungen in]
fnc: registerDetailFrameClickHandler (jquery variable)
fnc: onDetailFrameClick (case für )


[Dokumentation]
fnc: registerDetailFrameClickHandler
    Prüfung auf Attribut "data-action-detail"
    wird an fnc: onDetailFrameClick übergeben

fnc: onDetailFrameClick
    Abfrage des Attributs "action-mode", Weitergabe bei "cancel" und "close"
    Argument "dataAction" wird via switch-case ausgewertet
    wenn nicht vorhanden (case-default), dann Abbruch mit console.error(dataAction)

    case-default als extenion-point für intercepter implementieren
